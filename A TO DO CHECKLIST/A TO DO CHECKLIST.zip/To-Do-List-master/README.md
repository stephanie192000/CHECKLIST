# To-Do-List
A simple HTML,CSS,JAVASCIPT project to create a to-do list
